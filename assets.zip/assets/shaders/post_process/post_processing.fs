#version 330 core

in vec2 uv;

out vec4 vertexColor;

uniform sampler2D tx_fbo;

void main(void)
{
	vertexColor = texture(tx_fbo, uv);	
}

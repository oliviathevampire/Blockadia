#extern version.glsl

in float sun_dist;
in float fog_factor;
in float color_factor;

out vec4 vertexColor;

uniform vec3 sun_color;
uniform vec3 sky_color;
uniform vec3 fog_color;

uniform float sun_intensity;

void main(void)
{
	//1.0 is skydome size
	float sun_radius = (1.0 / 8.0f) * sun_intensity;
	
	if (sun_dist < sun_radius) {
		vertexColor = vec4(sun_color, 1.0);	
		return ;
	}
	
	float sun_ray = sun_radius * 4;
		
	if (sun_dist < sun_ray) {
		float f = sun_dist / sun_ray;
		vertexColor = mix(vec4(sun_color, 1.0), vec4(sky_color, 1.0), f * f);
	} else {
		vertexColor = vec4(sky_color, 1.0);
	}
	vertexColor.xyz += color_factor;
	
	vertexColor = mix(vertexColor, vec4(fog_color, 1.0), fog_factor);
}

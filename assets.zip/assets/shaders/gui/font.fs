#version 330 core

in vec2 pass_uv;
in vec4 pass_color;

out vec4 vertexColor;

uniform sampler2D tx_font;

uniform float transparency;

uniform float width;
uniform float edge;

uniform float border_width; //default font : set it to 0
uniform float border_edge;

uniform vec2 outline_offset; //default font : set it to vec2(0, 0)
uniform vec3 outline_color;

void main(void) {
	
	float distance = 1 - texture(tx_font, pass_uv).a;
	float alpha = 1.0 - smoothstep(width, width + edge, distance);
	
	distance = 1 - texture(tx_font, pass_uv + outline_offset).a;
	float outline_alpha = 1.0 - smoothstep(border_width, border_width + border_edge, distance);
	
	float all_alpha = alpha + (1.0 - alpha) * outline_alpha;
	vec3 all_color = mix(outline_color, pass_color.xyz, alpha / all_alpha);
	
	vertexColor = vec4(all_color, all_alpha * pass_color.w * transparency);
}

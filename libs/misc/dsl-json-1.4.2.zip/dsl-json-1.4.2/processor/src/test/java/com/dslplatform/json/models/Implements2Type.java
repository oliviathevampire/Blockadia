package com.dslplatform.json.models;

import com.dslplatform.json.CompiledJson;

@CompiledJson
public class Implements2Type implements InterfaceType {
	public int x;
}

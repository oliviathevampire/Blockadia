package com.dslplatform.json.models;

import com.dslplatform.json.CompiledJson;

@CompiledJson
public class ExtendsType extends AbstractType {
	public String x;
}

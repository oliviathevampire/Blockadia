package com.dslplatform.json.models;

import com.dslplatform.json.CompiledJson;

public class NestedStaticClass {
	@CompiledJson
	public static class StaticClass {
	}
}

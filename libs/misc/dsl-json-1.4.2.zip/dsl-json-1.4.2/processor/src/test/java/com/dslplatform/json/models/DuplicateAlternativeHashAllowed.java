package com.dslplatform.json.models;

import com.dslplatform.json.CompiledJson;
import com.dslplatform.json.JsonAttribute;

@CompiledJson
public class DuplicateAlternativeHashAllowed {
	@JsonAttribute(alternativeNames = {"n519524"})
	public int n3307663;
}

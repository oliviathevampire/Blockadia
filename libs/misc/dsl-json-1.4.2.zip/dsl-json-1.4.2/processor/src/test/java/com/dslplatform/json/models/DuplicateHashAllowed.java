package com.dslplatform.json.models;

import com.dslplatform.json.CompiledJson;

@CompiledJson
public class DuplicateHashAllowed {
	public int n3307663;
	public int n519524;
}

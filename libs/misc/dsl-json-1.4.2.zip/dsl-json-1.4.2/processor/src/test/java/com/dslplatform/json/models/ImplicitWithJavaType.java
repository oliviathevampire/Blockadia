package com.dslplatform.json.models;

import java.util.Date;

public class ImplicitWithJavaType {
	public Date date;
}

package com.dslplatform.json.models;

import com.dslplatform.json.CompiledJson;

@CompiledJson
public class ReferenceToImplicitWithJavaType {
	public ImplicitWithJavaType prop;
}

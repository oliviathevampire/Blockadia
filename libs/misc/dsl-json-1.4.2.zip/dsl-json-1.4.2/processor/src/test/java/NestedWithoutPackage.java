import com.dslplatform.json.CompiledJson;

public class NestedWithoutPackage {
	@CompiledJson
	public static class Nested {}
}

package com.dslplatform.json.models;

import com.dslplatform.json.CompiledJson;

@CompiledJson(typeSignature = CompiledJson.TypeSignature.EXCLUDE)
public abstract class AbstractTypeWithoutSignature {
	public long y;
}

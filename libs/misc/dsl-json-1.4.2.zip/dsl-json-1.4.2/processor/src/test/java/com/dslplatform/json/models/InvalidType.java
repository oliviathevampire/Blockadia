package com.dslplatform.json.models;

import com.dslplatform.json.CompiledJson;

@CompiledJson
public class InvalidType {
	private char prop;

	public char getProp() {
		return prop;
	}

	public void setProp(char value) {
		prop = value;
	}
}

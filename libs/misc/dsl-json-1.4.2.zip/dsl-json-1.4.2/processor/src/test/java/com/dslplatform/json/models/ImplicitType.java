package com.dslplatform.json.models;

public class ImplicitType {
}

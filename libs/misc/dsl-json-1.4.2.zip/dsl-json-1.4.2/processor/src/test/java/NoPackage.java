import com.dslplatform.json.CompiledJson;

@CompiledJson
public class NoPackage {
}

package com.dslplatform.json;

@CompiledJson
class NonPublicClass {
	public NonPublicClass() {
	}
}
package com.dslplatform.json.models;

import com.dslplatform.json.CompiledJson;

@CompiledJson(deserializeAs = DeserializeAsSelf.class)
public class DeserializeAsSelf {
	public long y;
}

package com.dslplatform.json.models;

import com.dslplatform.json.CompiledJson;

public class NestedNonStaticClass {
	@CompiledJson
	public class NonStaticClass {
	}
}

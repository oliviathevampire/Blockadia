package com.dslplatform.json.models;

import com.dslplatform.json.CompiledJson;

@CompiledJson
public class ExtendsTypeWithConfiguration extends AbstractTypeWithoutSignature {
	public String x;
}

package com.dslplatform.json.models;

import com.dslplatform.json.CompiledJson;

@CompiledJson
public class MissingEmptyCtor {
	public MissingEmptyCtor(int i) {
	}
}

package com.dslplatform.json.models;

import com.dslplatform.json.CompiledJson;
import com.dslplatform.json.JsonAttribute;

@CompiledJson
public class DuplicateHashNotAllowed {
	public int n3307663;
	@JsonAttribute(alternativeNames = {"n519524"})
	public int p2;
}

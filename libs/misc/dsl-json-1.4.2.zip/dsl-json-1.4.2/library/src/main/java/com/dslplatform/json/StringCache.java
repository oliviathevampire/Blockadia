package com.dslplatform.json;

public interface StringCache {
	String get(char[] chars, int len);
}
